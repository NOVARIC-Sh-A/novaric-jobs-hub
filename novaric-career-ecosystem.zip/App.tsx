import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Dashboard } from './components/Dashboard';
import { JobRecommendations } from './components/JobRecommendations';
import { CareerPathfinder } from './components/CareerPathfinder';
import { SkillsGapAnalyzer } from './components/SkillsGapAnalyzer';
import { Learning } from './components/Learning';
import { Community } from './components/Community';
import { BrandGuidelines } from './components/BrandGuidelines';
import { JobListingPage } from './components/pages/JobListingPage';
import { StaticPage } from './components/pages/StaticPage';
import { ContactPage } from './components/pages/ContactPage';
import { View, PageContext } from './types';
import { NovaricRecruitmentPage } from './components/pages/NovaricRecruitmentPage';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.DASHBOARD);
  const [pageContext, setPageContext] = useState<PageContext | null>(null);

  const navigateTo = (view: View, context: PageContext | null = null) => {
    setCurrentView(view);
    setPageContext(context);
    window.scrollTo(0, 0);
  };

  const renderView = useCallback((): React.ReactNode => {
    switch (currentView) {
      case View.DASHBOARD:
        return <Dashboard setView={navigateTo} />;
      case View.JOBS:
        return <JobRecommendations />;
      case View.CAREER_PATH:
        return <CareerPathfinder />;
      case View.SKILLS_GAP:
        return <SkillsGapAnalyzer />;
      case View.LEARNING:
        return <Learning />;
      case View.COMMUNITY:
        return <Community />;
      case View.RECRUITMENT:
        return <NovaricRecruitmentPage setView={navigateTo} />;
      case View.BRAND_GUIDELINES:
        return <BrandGuidelines />;
      case View.JOB_LISTING:
        return <JobListingPage context={pageContext} />;
      case View.COOKIE_POLICY:
      case View.PRIVACY_POLICY:
      case View.TERMS_OF_USE:
      case View.ALL_JOBS:
      case View.CAREER_ADVICE:
      case View.CAREERS_AT_NOVARIC:
      case View.STAFFING_SOLUTIONS:
      case View.WORKFORCE_INSIGHTS:
      case View.DIGITAL_SERVICES:
      case View.COMPANY_PROFILE:
      case View.SUSTAINABILITY:
      case View.PRESS:
      case View.INVESTORS:
      case View.DISCLAIMER:
      case View.ACCESSIBILITY:
      case View.SITEMAP:
      case View.MISCONDUCT_POLICY:
        return <StaticPage context={pageContext} />;
      case View.CONTACT:
        return <ContactPage />;
      default:
        return <Dashboard setView={navigateTo} />;
    }
  }, [currentView, pageContext]);

  return (
    <div className="flex flex-col min-h-screen font-sans text-slate-800 dark:text-slate-200">
      <Header currentView={currentView} setView={navigateTo} />
      <main className="flex-grow container mx-auto px-4 py-8">
        {renderView()}
      </main>
      <Footer setView={navigateTo} />
    </div>
  );
};

export default App;