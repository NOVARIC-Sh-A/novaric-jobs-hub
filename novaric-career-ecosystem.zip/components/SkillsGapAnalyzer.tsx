
import React, { useState, useCallback } from 'react';
import { analyzeSkillsGap } from '../services/geminiService';
import type { SkillGapResult, MissingSkill } from '../types';
import { Spinner } from './common/Spinner';
import { Icon } from './common/Icon';

const RecommendationIcon: React.FC<{ recommendation: string }> = ({ recommendation }) => {
    const isHire = recommendation.toLowerCase().includes('punësuar');
    const icon = isHire 
        ? <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
        : <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>;
    const color = isHire ? 'text-novaric-blue' : 'text-slate-500';

    return <Icon icon={icon} className={color} />;
};

const MissingSkillCard: React.FC<{ missingSkill: MissingSkill }> = ({ missingSkill }) => (
    <div className="bg-slate-100 dark:bg-slate-700 p-4 rounded-lg">
        <div className="flex items-center justify-between">
            <h4 className="text-lg font-bold text-slate-800 dark:text-white">{missingSkill.skill}</h4>
            <div className="flex items-center space-x-2">
                <RecommendationIcon recommendation={missingSkill.recommendation} />
                <span className="font-semibold text-sm text-slate-600 dark:text-slate-300">{missingSkill.recommendation}</span>
            </div>
        </div>
        <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">{missingSkill.reasoning}</p>
    </div>
);

export const SkillsGapAnalyzer: React.FC = () => {
  const [teamSkills, setTeamSkills] = useState('JavaScript, React, Node.js, HTML, CSS');
  const [projectDescription, setProjectDescription] = useState('Zhvilloni një platformë të re e-commerce me një portal për klientët, një panel administrimi për menaxhimin e produkteve dhe një motor rekomandimi.');
  const [result, setResult] = useState<SkillGapResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const apiResult = await analyzeSkillsGap(teamSkills, projectDescription);
      setResult(apiResult);
    } catch (err) {
      setError('Dështoi në analizimin e hendekut të aftësive. Ju lutemi kontrolloni çelësin tuaj të API-t dhe provoni përsëri.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [teamSkills, projectDescription]);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Analizuesi i Hendekut të Aftësive</h2>
        <p className="mt-2 text-slate-600 dark:text-slate-400">Për punëdhënësit: Identifikoni nevojat për talente për projektet tuaja të ardhshme.</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-8">
        <div className="grid md:grid-cols-1 gap-6">
          <div>
            <label htmlFor="teamSkills" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Aftësitë Aktuale të Ekipit</label>
            <textarea
              id="teamSkills"
              rows={3}
              value={teamSkills}
              onChange={(e) => setTeamSkills(e.target.value)}
              className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-novaric-blue focus:border-novaric-blue"
              placeholder="p.sh., Python, SQL, AWS, Analizë të Dhënash"
            />
          </div>
          <div>
            <label htmlFor="projectDescription" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Përshkrimi i Projektit</label>
            <textarea
              id="projectDescription"
              rows={4}
              value={projectDescription}
              onChange={(e) => setProjectDescription(e.target.value)}
              className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-novaric-blue focus:border-novaric-blue"
              placeholder="p.sh., Ndërtoni një model machine learning për të parashikuar largimin e klientëve."
            />
          </div>
        </div>
        <div className="mt-6 text-center">
          <button type="submit" disabled={loading} className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-novaric-red hover:bg-novaric-red/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-novaric-red disabled:bg-slate-400">
            {loading ? 'Duke analizuar...' : 'Analizo Hendekun e Aftësive'}
          </button>
        </div>
      </form>

      {loading && <Spinner />}
      {error && <p className="text-center text-red-500 bg-red-100 dark:bg-red-900/50 p-3 rounded-md">{error}</p>}
      
      {!loading && result && (
        <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg">
            <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-200 mb-4">Rezultatet e Analizës</h3>
            <div className="bg-slate-50 dark:bg-slate-900/50 p-4 rounded-md mb-6">
                <h4 className="font-semibold text-lg text-slate-700 dark:text-slate-200">Përmbledhje</h4>
                <p className="mt-1 text-slate-600 dark:text-slate-300">{result.summary}</p>
            </div>

            <h4 className="font-semibold text-lg text-slate-700 dark:text-slate-200 mb-4">Veprime të Rekomanduara</h4>
            <div className="space-y-4">
                {result.missingSkills.map((skill, index) => (
                    <MissingSkillCard key={index} missingSkill={skill} />
                ))}
            </div>
        </div>
      )}
    </div>
  );
};